import java.io.File;

import org.apache.commons.io.FileUtils;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

public class TestClass {
	public static void main(String[] args) {
		try {
			File file = new File("D://testdemo.txt");

			// StandardPBEStringEncryptor encryptorDecryptor = new
			// StandardPBEStringEncryptor();
			// encryptorDecryptor.setPassword("AB");
			// String encryptedFileContent =
			// encryptorDecryptor.encrypt(FileUtils.readFileToString(file));
			// FileUtils.writeStringToFile(file, encryptedFileContent);

			StandardPBEStringEncryptor encryptorDecryptor = new StandardPBEStringEncryptor();
			encryptorDecryptor.setPassword("AB");
			String encryptedFileContent = encryptorDecryptor.decrypt(FileUtils.readFileToString(file));
			FileUtils.writeStringToFile(file, encryptedFileContent);

			System.out.println("Complted");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
