package com.kpabe.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kpabe.connection.DBManager;



@SuppressWarnings("serial")
public class RegistrationServlet extends HttpServlet{
	
	public void doPost(HttpServletRequest request,HttpServletResponse response)
throws ServletException, IOException {
		String username= request.getParameter("username"); 
		String firstName= request.getParameter("firstName"); 
		String lastName= request.getParameter("lastName");
		String email= request.getParameter("email"); 
		String designation= request.getParameter("designation");
		if(designation.equals("NA")){
			designation="";
		}
		String team= request.getParameter("team");
		if(team.equals("NA")){
			team="";
		}
		String department= request.getParameter("department");
		if(department.equals("NA")){
			department="";
		}
		String password = username.substring(0, 4)+department+team+designation;
		DBManager dbm= new DBManager();
		HttpSession session = request.getSession();
		if(!dbm.validUserName(username)){
			dbm.insertUser(firstName, lastName, username, password, designation, team, department, email);
			session.setAttribute("msg","Registration Successful:: Your password : "+password+"!");
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
		else{
			
			session.setAttribute("msg", "Username already exists!!");
			request.getRequestDispatcher("Registration.jsp").forward(request, response);
		}
}

}
