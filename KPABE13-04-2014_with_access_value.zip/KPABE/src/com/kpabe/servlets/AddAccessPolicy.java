package com.kpabe.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.kpabe.connection.DBManager;

/**
 * Servlet implementation class AddAccessPolicy
 */
public class AddAccessPolicy extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddAccessPolicy() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DBManager dbm= new DBManager();
		HttpSession session = request.getSession();
		String designation1=null,designation2=null,team1=null,team2=null,access_expression = "",operation=null; 
		designation1= request.getParameter("designation1");
		designation2= request.getParameter("designation2");
		team1= request.getParameter("team1");
		team2= request.getParameter("team2");
		operation= request.getParameter("operation");
			
		if(((designation1.equals("--Select--"))&&(team1.equals("--Select--"))&&(designation2.equals("--Select--"))&&(team2.equals("--Select--")))){
			session.setAttribute("msg","Please Select key Policy!");
			request.getRequestDispatcher("HomePage.jsp").forward(request, response);
		}
		if(((!designation1.equals("--Select--"))&&(designation2.equals("--Select--"))&&(team1.equals("--Select--"))&&(team2.equals("--Select--"))))
		{//System.out.println("Inside designation1");
			access_expression =designation1 ;
		}
		if(((designation1.equals("--Select--"))&&(designation2.equals("--Select--"))&&(team2.equals("--Select--"))&& (!team1.equals("--Select--"))))
		{//System.out.println("Inside team1");
			access_expression = team1;
		}
		if((!designation1.equals("--Select--"))&&(!team1.equals("--Select--")))
		{//System.out.println("Inside designation1+team1");
			access_expression =designation1+operation+team1;
		}
		if(((!designation1.equals("--Select--"))&&(!designation2.equals("--Select--"))))
		{//System.out.println("Inside designation1+team1");
			access_expression =designation1+operation+designation2;
		}
		if(((!team1.equals("--Select--"))&&(!team2.equals("--Select--"))))
		{//System.out.println("Inside designation1+team1");
			access_expression =team1+operation+team2;
		}
		//logic for create access value
		String access_value = getAccessValue(designation1,designation2,team1,team2,operation);
		
		//System.out.println(access_value);
		int fileId = (Integer) session.getAttribute("fileId");
		System.out.println("access_expression"+access_expression);
		System.out.println("access_value"+access_value);
		if(dbm.updateFileAccessPolicy(access_expression, access_value,fileId)){
        	//session.setAttribute("fileId", fileId);
        	session.setAttribute("msg","Upload Successfull!");
        	request.getRequestDispatcher("HomePage.jsp").forward(request, response);
        }else{
        	session.setAttribute("msg","Upload Failed!");
			request.getRequestDispatcher("HomePage.jsp").forward(request, response);
        }
        
		/*System.out.println(request.getParameter("designation1"));
		System.out.println(request.getParameter("designation2"));
		System.out.println(request.getParameter("team1"));
		System.out.println(request.getParameter("team2"));
		System.out.println(request.getParameter("operation"));
		//System.out.println("access_expression=="+access_expression);
		*/
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println(request.getParameter("designation1"));
		System.out.println(request.getParameter("designation2"));
		System.out.println(request.getParameter("team1"));
		System.out.println(request.getParameter("team2"));
		System.out.println(request.getParameter("operation"));
	}

	public String getAccessValue(String designation1,String designation2, String team1, String team2, String opeartion)
	{
		String result = null;
		int str=0,str1 = 0, str2 = 0;
		if(opeartion.equals("AND")){
			try{
				if(designation1.equals("CM"))
					str1 = 331;
				if(designation1.equals("TM"))
					str1 = 2013;
				if(designation1.equals("SSE"))
					str1 = 19195;
				if(designation1.equals("JSE"))
					str1 = 10195;
				if(designation1.equals("NA"))
					str1 = 141;
				
				if(team1.equals("PP"))
					str2 = 1616;
				if(team1.equals("EM"))
					str2 = 513;
				if(team1.equals("HSP"))
					str2 = 81917;
				if(team1.equals("NTZ"))
					str2 = 142026;
				if(team1.equals("EB"))
					str2 = 52;
				if(team1.equals("MX"))
					str2 = 1324;
				if(team1.equals("NA"))
					str2 = 141;
			}catch (Exception e) {
				// TODO: handle exception
			}	
		}
		else if(opeartion.equals("OR"))
		{			
			try{
				    if(designation1.equals("CM"))
						str1 = 331;
					if(designation1.equals("TM"))
						str1 = 2013;
					if(designation1.equals("SSE"))
						str1 = 19195;
					if(designation1.equals("JSE"))
						str1 = 10195;
					if(designation1.equals("NA"))
						str1 = 141;
					
					if(designation2.equals("CM"))
						str2 = 331;
					if(designation2.equals("TM"))
						str2 = 2013;
					if(designation2.equals("SSE"))
						str2 = 19195;
					if(designation2.equals("JSE"))
						str2 = 10195;
					if(designation2.equals("NA"))
						str2 = 141;
					//if team is selected
					
					if(team1.equals("PP"))
						str1 = 1616;
					if(team1.equals("EM"))
						str1 = 513;
					if(team1.equals("HSP"))
						str1 = 81917;
					if(team1.equals("NTZ"))
						str1 = 142026;
					if(team1.equals("EB"))
						str1 = 52;
					if(team1.equals("MX"))
						str1 = 1324;
					if(team1.equals("NA"))
						str1 = 141;
					
					if(team2.equals("PP"))
						str2 = 1616;
					if(team2.equals("EM"))
						str2 = 513;
					if(team2.equals("HSP"))
						str2 = 81917;
					if(team2.equals("NTZ"))
						str2 = 142026;
					if(team2.equals("EB"))
						str2 = 52;
					if(team2.equals("MX"))
						str2 = 1324;
					if(team2.equals("NA"))
						str2 = 141;
					
			}catch (Exception e) {
				// TODO: handle exception
			}
		}
		else if(opeartion.equals("--Select--")){
			try{
				if(designation1.equals("CM"))
					str = 331;
				if(designation1.equals("TM"))
					str = 2013;
				if(designation1.equals("SSE"))
					str = 19195;
				if(designation1.equals("JSE"))
					str = 10195;
				if(designation1.equals("NA"))
					str = 141;
				if(team1.equals("PP"))
					str = 1616;
				if(team1.equals("EM"))
					str = 513;
				if(team1.equals("HSP"))
					str = 81917;
				if(team1.equals("NTZ"))
					str = 142026;
				if(team1.equals("EB"))
					str = 52;
				if(team1.equals("MX"))
					str = 1324;
				if(team1.equals("NA"))
					str = 141;
			}
			catch (Exception e) {
				// TODO: handle exception
			}
		}
		int resultAND;
			if(opeartion.equals("OR")){
				result = str1+","+str2;
				System.out.println("resutl:"+result);
			}
			else if(opeartion.equalsIgnoreCase("AND")){
				resultAND = str1 & str2;
				result = ""+resultAND; 
			}
			if(opeartion.equals("--Select--")){
				result = ""+str;
			}
		
		//logic for creating access value
		System.out.println(result);;
		return result;
	}
}
