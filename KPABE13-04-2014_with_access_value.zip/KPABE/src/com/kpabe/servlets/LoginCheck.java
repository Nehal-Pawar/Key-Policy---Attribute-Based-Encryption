package com.kpabe.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kpabe.connection.DBManager;

@SuppressWarnings("serial")
public class LoginCheck extends HttpServlet{
	
	public void doPost(HttpServletRequest request,HttpServletResponse response)
throws ServletException, IOException {
		String username= request.getParameter("username"); 
		String password= request.getParameter("password");
		String isAdmin= request.getParameter("isAdmin");
		DBManager dbm= new DBManager();
		try {
			if(isAdmin!=null && isAdmin.equals(isAdmin)){
			if(dbm.validateAdmin(username, password)){
				HttpSession session = request.getSession();
				session.setAttribute("username",username);
				response.sendRedirect("HomePage.jsp");
			}
			else{
				HttpSession session = request.getSession();
				session.setAttribute("msg", "Incorrect username or password");
				request.getRequestDispatcher("index.jsp").forward(request, response);
			PrintWriter out = response.getWriter();
			out.print("Login Failed!!");
			}
			}
			else
			{
				if(dbm.validateUser(username, password)){
					HttpSession session = request.getSession();
					session.setAttribute("username",username);
					response.sendRedirect("ViewFiles.jsp");
				}else{
					HttpSession session = request.getSession();
					session.setAttribute("msg", "Incorrect username or password");
					request.getRequestDispatcher("index.jsp").forward(request, response);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
}

}
