package com.kpabe.servlets;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kpabe.connection.DBManager;
import com.kpabe.objects.userInfo;


/**
 * Servlet implementation class downloadFile
 */
public class downloadFile extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final int BUFFER_SIZE = 4096;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public downloadFile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	try	{
		HttpSession session = request.getSession();
		String fileName = request.getParameter("filename");
		int fileId = Integer.parseInt(request.getParameter("fileId"));
		String username = (String) session.getAttribute("username");
		//get users designation and team value
		
		int access_value = 0;
		
		DBManager dbm= new DBManager();
		
		
		userInfo user=dbm.getUserInfo(username);
		String designation = user.getDesignation();
		String team = user.getTeam();
		int str1 = 0,str2 = 0; 
		if(designation.equals("CM"))
			str1 = 331;
		if(designation.equals("TM"))
			str1 = 2013;
		if(designation.equals("SSE"))
			str1 = 19195;
		if(designation.equals("JSE"))
			str1 = 10195;
		if(designation.equals("NA"))
			str1 = 141;
		if(team.equals("PP"))
			str2 = 1616;
		if(team.equals("EM"))
			str2 = 513;
		if(team.equals("HSP"))
			str2 = 81917;
		if(team.equals("NTZ"))
			str2 = 142026;
		if(team.equals("EB"))
			str2 = 52;
		if(team.equals("MX"))
			str2 = 1324;
		if(team.equals("NA"))
			str2 = 141;
		String access_val = null;
		System.out.println(request.getParameter("filename"));
		System.out.println(session.getAttribute("username"));
		//get files acess expression and acess value
		String access_exp = dbm.getAccessExpression(fileId);
		//fileInfo = db.getFileInfo(filename);
		//if string access.expression coantain AND then operator= AND
		System.out.println("FileName:"+fileName);
		System.out.println("access_exp:"+access_exp);
		 
		if(access_exp.contains("AND")){
			System.out.println("AND");
			access_value = str1 & str2;
		}
		//else if access.expression coantain OR then operator = OR
		else  if(access_exp.contains("OR")){
				 System.out.println("OR");
			 	
				access_val = str1 +","+ str2 ; 
				}
		//else if fileInfo.acess_expression == user.designation or acess_exptrssion==user.team
		else if(access_exp.equals(designation))
				access_value = str1;
		else if(access_exp.equals(team))
				access_value =	str2;
		if(access_value!=0)
		access_val = ""+access_value;
		//check the permission
		if(dbm.isAccess_permission(access_val, fileName)){
			//dowmload file if user have an permiossion
			try{
				System.out.println("Download acess");
				session.setAttribute("msg","");
				Blob blob= dbm.download(fileName);
				InputStream inputStream = blob.getBinaryStream();
	            int fileLength = inputStream.available();
	            System.out.println("fileLength = " + fileLength);
	            ServletContext context = getServletContext();
	            
	            // sets MIME type for the file download
	            String mimeType = context.getMimeType((String) fileName);
	            if (mimeType == null) {        
	                mimeType = "application/octet-stream";
	            }              
             
            // set content properties and header attributes for the response
            response.setContentType(mimeType);
            response.setContentLength(fileLength);
            String headerKey = "Content-Disposition";
            String headerValue = String.format("attachment; filename=\"%s\"", fileName);
            response.setHeader(headerKey, headerValue);

            // writes the file to the client
            OutputStream outStream = response.getOutputStream();
             
            byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead = -1;
             
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outStream.write(buffer, 0, bytesRead);
            }
             inputStream.close();
            outStream.close();
            session.setAttribute("username",username);
    		response.sendRedirect("ViewFiles.jsp");
        /*} else {
            // no file found
            response.getWriter().print("File not found for the id: " + uploadId);  
        }*/
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		else
		{	System.out.println("Downlod Acess denid");
		response.getWriter().print("you dosen't have  permission to access this file. ");	
		session.setAttribute("msg","you dosen't have  permission to access this file.");
		session.setAttribute("username",username);
		response.sendRedirect("ViewFiles.jsp");
		}
		//redirect to view page
		
	}catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
  }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		String filename = request.getParameter("filename");
		String username = (String) session.getAttribute("username");
		//get users designation and team value
		
		int acess_vale;
		
		DBManager dbm= new DBManager();
		
		userInfo user=dbm.getUserInfo("username");
		System.out.println("designation:"+user.getDesignation());
		System.out.println("team="+user.getTeam());
		System.out.println("id="+user.getId());
		System.out.println("Name"+user.getusername());
		
		System.out.println(request.getParameter("filename"));
		System.out.println(session.getAttribute("username"));
		//dowmload file
		session.setAttribute("msg","");
		//else
		//msg user dosent have an permission to access this file.
		session.setAttribute("msg","you dosen't have  permission to access this file.");
		//redirect to view page
		session.setAttribute("username",username);
		response.sendRedirect("ViewFiles.jsp");
	}

}
