package com.kpabe.connection;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.InputStream;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;

import com.sun.org.apache.xalan.internal.xsltc.compiler.sym;
import com.sun.xml.internal.org.jvnet.fastinfoset.ExternalVocabulary;
import com.kpabe.objects.userInfo;
public class DBManager {
	public static Connection conn;
	
	public DBManager(){	
        try {
            String dbURL = "jdbc:mysql://localhost:3306/kpabe";
            String username = "root";
            String password = "root123";

            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(dbURL, username, password);

	}catch(Exception e){
		e.printStackTrace();
	}
	}
	
 /* Method to validate an employee and register its device into database*/
	public boolean validateUser(String username,String password) throws SQLException {
		boolean result = false;
		Statement stmt = conn.createStatement();
		String strSelect = "select username,password from user";
        ResultSet rset = stmt.executeQuery(strSelect);
        while(rset.next()){
        	if(username.equals(rset.getString("username"))&& password.equals(rset.getString("password"))){
        		result= true;
        	}
        }
        stmt.close();
        return result;
	}
	
	
	/* Method to insert user into database*/
	public boolean insertUser(String firstName,
			String lastName, String username, String password, String designation,String team,
			String department,String email){
		boolean result = false;
		
		
		try{
		PreparedStatement pstmt= conn.prepareStatement("insert into user(first_name,last_name,username,password,designation,team,department,email) values(?,?,?,?,?,?,?,?)");
		pstmt.setString(1,firstName);
		pstmt.setString(2,lastName);
		pstmt.setString(3,username);
		pstmt.setString(4,password);
		pstmt.setString(5,designation);
		pstmt.setString(6,team);
		pstmt.setString(7,department);
		pstmt.setString(8,email);
		
		if(pstmt.executeUpdate()==1){
			result = true;
		}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	/* Method to insert user into database*/
	public boolean updatetUser( String designation,String team,
			String department,int userId){
		boolean result = false;
		try{
			PreparedStatement pstmt= conn.prepareStatement("update  user set designation=?,team=?,department=? where id=?");
			pstmt.setString(1,designation);
			pstmt.setString(2,team);
			pstmt.setString(3,department);
			pstmt.setInt(4,userId);
			
			if(pstmt.executeUpdate()==1){
				result = true;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	/*Method to validate login credentials for portal*/
	public boolean validateAdmin(String adminname, String password) throws SQLException { 
		boolean result = false;
		Statement stmt = conn.createStatement();
		String strSelect = "select admin_name, admin_password from admin";
        ResultSet rset = stmt.executeQuery(strSelect);
        while(rset.next()){
        	if(adminname.equals(rset.getString("admin_name"))&& password.equals(rset.getString("admin_password"))){
        		result= true;
        	}
        }
        stmt.close();
        return result;

	}

	/* Method to validate a user by checking username */
	public boolean validUserName(String username){
		boolean result = false;
		Statement stmt;
		try {
			stmt = conn.createStatement();
		
		String strSelect = "select username from user";
        ResultSet rset = stmt.executeQuery(strSelect);
        while(rset.next()){
        	if(username.equals(rset.getString("username"))){
        		result= true;
        		break;
        	}
        }
        stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		 return result;	
	}
	public boolean isFileExist(String fileName){
		boolean result= false;
		try{
		PreparedStatement pstmt= conn.prepareStatement("select id from file where file_name = ?");
		pstmt.setString(1,fileName); 
		ResultSet rset = pstmt.executeQuery();
		while(rset.next()){
				result = true;
				break;
		}
		pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	 return result;

		
	}
	public boolean saveFileToDatabase(String fileName, FileInputStream fstream) {
		boolean result = false;
		try{
		PreparedStatement pstmt= conn.prepareStatement("insert into file(file_name,file_data) values(?,?)");
		pstmt.setString(1,fileName); 
		pstmt.setBlob(2,fstream);
		if(pstmt.executeUpdate()==1){
			result = true;
		}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
    
	public int getFileIDByName(String fileName) {
		int result = 0;
		try {
			PreparedStatement pstmt= conn.prepareStatement("select id from file where file_name = ?");
			pstmt.setString(1,fileName); 
        ResultSet rset = pstmt.executeQuery();
        while(rset.next()){
        		result= rset.getInt("id");
        		break;
        }
        pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		 return result;
	}

	public boolean updateFileAccessPolicy(String access_expression,String access_value,int fileId)
	{
		boolean result = false;
		System.out.println("Inaccess_expression:::"+access_expression);
		System.out.println("Inaccess_value::"+access_value);
		System.out.println("fileId::"+fileId);
		try{
			PreparedStatement pstmt= conn.prepareStatement("update file SET access_expression = ?,access_value=? WHERE id = ?");
			pstmt.setString(1,access_expression);
			pstmt.setString(2,access_value);
			pstmt.setInt(3,fileId);
			if(pstmt.executeUpdate()==1){
				result = true;
			}
			}catch (Exception e) {
				e.printStackTrace();
			}
			return result;
		}
	
	public HashMap<Integer,String> getViewFiles()
	{
		HashMap<Integer,String> result = new HashMap<Integer,String>();
		try{
			Statement stmt= conn.createStatement();
			ResultSet rset = stmt.executeQuery("select * from file");
			while(rset.next()){
	        	result.put(rset.getInt("id"),rset.getString("file_name"));
	        	}
	         stmt.close();
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		
		return result;
		
	}
	public ResultSet getViewFilesNew()
	{
		ResultSet rset =null;
		try{
			Statement stmt= conn.createStatement();
			rset = stmt.executeQuery("select * from file");
			
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		
		return rset;
		
	}
	public String getAccessExpression(int fileId)
	{
		String accessExpression = null;
		try {
			System.out.println("Inside db :"+fileId);
			PreparedStatement pstmt= conn.prepareStatement("select access_expression from file where id =?");
			pstmt.setInt(1,fileId); 
			System.out.println(pstmt);
			ResultSet rset = pstmt.executeQuery();
			while(rset.next()){
				accessExpression= rset.getString("access_expression");
				break;
        	}
			pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return accessExpression;
		
	}
	
	public boolean isAccess_permission(String access_value,String fileName)
	{	boolean result = false;
		try{
		PreparedStatement pstmt= conn.prepareStatement("select access_value,file_name from file");
		ResultSet rset = pstmt.executeQuery();
		while(rset.next())
		{
			if((fileName.equals(rset.getString("file_name"))))
			{	if(access_value.contains(","))
				{
				String[] str_array1 = access_value.split(",");
				String str1 = str_array1[0]; 
				String str2 = str_array1[1];
				String[] str_array2 = rset.getString("access_value").split(",");
				String str3 = str_array2[0]; 
				String str4 = str_array2[1];
				if(str1.equals(str3)|| str1.equals(str4)||str2.equals(str3)|| str2.equals(str4)){
					result = true;
				}
				}
				else if(access_value.equals(rset.getString("access_value")))
					result = true;
				break;
			}
		}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return result;
		
	}
	
	public userInfo getUserInfo(String username)
	{   userInfo userInfo = new userInfo();
		
	try{
		PreparedStatement pstmt = conn.prepareStatement("select * from user where username=?");
		pstmt.setString(1, username);
        ResultSet rset = pstmt.executeQuery();
		while(rset.next()){
        	userInfo.setId(rset.getString("id"));
        	userInfo.setusername(rset.getString("username"));
        	userInfo.setDesignation(rset.getString("designation"));
        	userInfo.setTeam(rset.getString("team"));
        	userInfo.setDepartment(rset.getString("department"));
        	System.out.println("Department"+rset.getString("designation"));
        	}
        }
		catch (Exception e) {
			e.printStackTrace();
		}
	
		return userInfo;
		
	}

	public userInfo getUserDetail(int userId)
	{   userInfo userInfo = new userInfo();
		
	try{
		PreparedStatement pstmt = conn.prepareStatement("select * from user where id=?");
		pstmt.setInt(1, userId);
        ResultSet rset = pstmt.executeQuery();
		while(rset.next()){
        	userInfo.setId(rset.getString("id"));
        	userInfo.setusername(rset.getString("username"));
        	userInfo.setDesignation(rset.getString("designation"));
        	userInfo.setTeam(rset.getString("team"));
        	userInfo.setDepartment(rset.getString("department"));
        	System.out.println("Department"+rset.getString("department"));
        	}
        }
		catch (Exception e) {
			e.printStackTrace();
		}
	
		return userInfo;
		
	}
	public Blob download(String fileName) {
		Blob blob = null;
		try{
			PreparedStatement pstmt= conn.prepareStatement("select * from file");
			ResultSet rset = pstmt.executeQuery();
			
			while(rset.next())
			{
			  if(fileName.equals(rset.getString("file_name"))){
				  blob = rset.getBlob("file_data");
				  break;
			  }
			}
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		return blob;
	}
	public ArrayList<userInfo> userInfo()
	{ 
		ArrayList<userInfo> userInfoList =new ArrayList<userInfo>();
		try{
		PreparedStatement pstmt = conn.prepareStatement("select * from user");
		 ResultSet rset = pstmt.executeQuery();
		System.out.println(pstmt);
		 while(rset.next()){
			userInfo user = new userInfo();
        	user.setId(rset.getString("id"));
        	user.setusername(rset.getString("username"));
        	user.setDesignation(rset.getString("designation"));
        	user.setTeam(rset.getString("team"));
        	user.setDepartment(rset.getString("department"));
        	userInfoList.add(user);
        	}
        }catch (Exception e) {
			// TODO: handle exception
        	e.printStackTrace();
		}
		
		return userInfoList;
		
	}
}
