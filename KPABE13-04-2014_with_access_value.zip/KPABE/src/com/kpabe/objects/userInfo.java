package com.kpabe.objects;

public class userInfo {
	private String id;
	private String username;
	private String designation;
	private String team;
	private String department;
	
	
	public userInfo() {
		super();
	}
	public userInfo(String id, String username,
			String designation, String team, String department) {
		super();
		this.id = id;
		this.username = username;
		this.designation = designation;
		this.team = team;
		this.department=department;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getusername() {
		return username;
	}
	public void setusername(String username) {
		this.username = username;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getTeam() {
		return team;
	}
	public void setTeam(String team) {
		this.team = team;
	}
	@Override
	public String toString() {
		return "userInfo [id=" + id + ", username=" + username
				+ ", designation=" + designation + ",team=" + team
				+ "]";
	}
}
